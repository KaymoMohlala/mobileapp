import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  chats = [
    {
      fullName: 'John Doe',
      profileURL: './assets/imgs/user1.png'
    },
    {
      fullName: 'Samya Doe',
      profileURL: './assets/imgs/user2.png'
    },
    {
      fullName: 'Dannie Doe',
      profileURL: './assets/imgs/user3.png'
    },
    {
      fullName: 'Sammy Doe',
      profileURL: './assets/imgs/user4.png'
    },
    {
      fullName: 'John Doe',
      profileURL: './assets/imgs/user1.png'
    },
    {
      fullName: 'Samya Doe',
      profileURL: './assets/imgs/user2.png'
    },
    {
      fullName: 'Dannie Doe',
      profileURL: './assets/imgs/user3.png'
    },
    {
      fullName: 'Sammy Doe',
      profileURL: './assets/imgs/user4.png'
    }
  ];

  constructor() { }

}
